# Building blocks of simulation

## Writing custom functions

## Handling errors or warnings
